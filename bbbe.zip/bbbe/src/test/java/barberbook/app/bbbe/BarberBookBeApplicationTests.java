package barberbook.app.bbbe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BarberBookBeApplicationTests {

	@Test
	void contextLoads() {
	}

}
